# 1.0.8

* Usuário pode escolher se quer usar HTTP (default) ou HTTPS 
na requisição a CalcPrecoPrazo. Para isso é necessário definir
na instanciação da classe `Sigepweb` o atributo `useSSL`

# 1.0.7

* CORS policy para requisição via web

# 1.0.6

* Regras de acordo com package pedantic

# 1.0.5

* Omit type annotations for local variables.

# 1.0.4

* `_homEndpoint` e `_prodEndpoint` agora campo final.

# 1.0.3

* Realizar testes sem incluir o flutter efetivamente como dependencia. Este package
deve poder ser usado em qualquer projeto Dart. 
* Ps.: Eu ainda não sei se o package `flutter_coverage_badge` vai fazer o projeto
ser notado como dependente do Flutter.

# 1.0.2

* Bug de referencia CalcPrecoPrazoItem foi mudado para CalcPrecoPrazoItemModel
* Foi feita tambem uma refatoracao em todo o código para traduzir tudo para PtBR
* O metodo calcPrecoPrazo agora usa a convenção Parker (mais simples) de XML para JSON
* Foram adicionados um pouco mais de testes e o coverage aumentou um pouquinho

# 1.0.1

* Exposing models

# 1.0.0

* Release first version stable, even only with 2 methods available

# 0.0.8

* Coverage update

# 0.0.7

* Docs update

# 0.0.6

* Docs and example update

# 0.0.5

* Joined classes `SigepwebPrecoPrazo` with `Sigepweb`, it means only one main class to use all methods
* Service consultaCEP can already be used

# 0.0.4

* Providing an example to the package

# 0.0.3

* Improving pub points of the package

# 0.0.2

* Name of the service with model CalcPrecoPrazoItem and method for test CEP numbers.

# 0.0.1

* Initializing the package only with CalcPrecoPrazo method available.
